import axios from 'axios';

/**
 * Base URL resolution order:
 * 1. REACT_APP_API_BASE_URL from .env.development / .env.production (recommended)
 * 2. Fallback: localhost while developing, current domain '/api' in production
 *
 * This lets the same build work against:
 *   - http://localhost:5000/api           (local dev)
 *   - https://mapmycareer360.com/api      (live domain)
 *   - http://196.xxx.xxx.xxx:5000/api     (raw server IP, e.g. before DNS is live)
 * Just set REACT_APP_API_BASE_URL in the relevant .env file - no code changes needed.
 */
function resolveBaseURL() {
  if (process.env.REACT_APP_API_BASE_URL) return process.env.REACT_APP_API_BASE_URL;
  if (process.env.NODE_ENV === 'production') return `${window.location.origin}/api`;
  return 'http://localhost:5000/api';
}

export const BASE_URL = resolveBaseURL();

const api = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' },
});

// Attach student/admin token automatically
api.interceptors.request.use((config) => {
  const adminToken = localStorage.getItem('mmc_admin_token');
  const studentToken = localStorage.getItem('mmc_student_token');
  const token = config.url?.startsWith('/admin') ? adminToken : (studentToken || adminToken);
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response && err.response.status === 401) {
      // token expired / invalid - let calling component decide what to do
    }
    return Promise.reject(err);
  }
);

export default api;
