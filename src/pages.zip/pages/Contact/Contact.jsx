import React, { useState } from 'react';
import api from '../../api/api.js';
import './Contact.css';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', message: '' });
  const [status, setStatus] = useState({ loading: false, sent: false, error: '' });

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus({ loading: true, sent: false, error: '' });
    try {
      await api.post('/contact', form);
      setStatus({ loading: false, sent: true, error: '' });
      setForm({ name: '', email: '', phone: '', message: '' });
    } catch (err) {
      setStatus({ loading: false, sent: false, error: 'Something went wrong. Please try again.' });
    }
  };

  return (
    <div className="mmc-contact-page">
      <div className="page-hero">
        <div className="container">
          <h1>Contact Us</h1>
          <p>Have a question about assessments, predictors or admissions? We're here to help.</p>
        </div>
      </div>

      <section className="section">
        <div className="container mmc-contact-grid">
          <div className="card mmc-contact-info">
            <h3>Reach Us</h3>
            <p>📍 Kasturi Nagar, Bangalore</p>
            <p>📞 <a href="tel:+919008804368">+91 90088 04368</a></p>
            <p>📞 <a href="tel:+916366018352">+91 63660 18352</a></p>
            <p>✉️ <a href="mailto:info@mapmycareer360.com">info@mapmycareer360.com</a></p>
            <p>💬 <a href="https://wa.link/czgq77" target="_blank" rel="noreferrer">Chat with us on WhatsApp</a></p>
          </div>

          <form className="card mmc-contact-form" onSubmit={handleSubmit}>
            <h3>Send a Message</h3>
            <div className="form-group">
              <label>Full Name</label>
              <input name="name" value={form.name} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Email</label>
              <input type="email" name="email" value={form.email} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Phone</label>
              <input name="phone" value={form.phone} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Message</label>
              <textarea name="message" rows="4" value={form.message} onChange={handleChange} required />
            </div>
            {status.error && <p className="error-state">{status.error}</p>}
            {status.sent && <p className="mmc-success-msg">Thanks! We'll get back to you shortly.</p>}
            <button className="btn btn-primary" type="submit" disabled={status.loading}>
              {status.loading ? 'Sending...' : 'Send Message'}
            </button>
          </form>
        </div>
      </section>
    </div>
  );
}